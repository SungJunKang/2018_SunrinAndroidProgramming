package com.example.sunrin.a20180328;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button btn1, btn2, btn3, btn4, btn5, btn6;
    String item[];
    int index;
    CheckBox checkBox;
    boolean choice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.btn1);
        btn2 = findViewById(R.id.btn2);
        btn3 = findViewById(R.id.btn3);
        btn4 = findViewById(R.id.btn4);
        btn5 = findViewById(R.id.btn5);
        btn6 = findViewById(R.id.btn6);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if(view == btn1){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setIcon(android.R.drawable.ic_dialog_alert);
            builder.setTitle("알림");
            builder.setMessage("정말 종료하시겠습니까?");
            builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    showToast("alert dialog OK click...");
                }
            });
            builder.setNegativeButton("NO", null);
            builder.setCancelable(false);

            AlertDialog alertDialog = builder.create();
            alertDialog.show();
        }

        else if(view == btn2){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("입장권 판매");
            item = new String[]{"어른", "청소년", "어린이"};
            builder.setItems(item, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    showToast(item[i]+ "이(가) 선택되었습니다.");
                }
            });
            builder.setNegativeButton("취소", null);
            builder.setCancelable(false);

            AlertDialog listDialog = builder.create();
            listDialog.show();
        }

        else if(view == btn3){
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("알람 벨소리");
            builder.setSingleChoiceItems(R.array.radio_array, 0, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    index = i;
                }
            });
            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    String[] datas = getResources().getStringArray(R.array.radio_array);
                    showToast(datas[index] + "이(가) 선택되었습니다.");
                }
            });
            builder.setNegativeButton("취소", null);

            AlertDialog radioDialog = builder.create();
            radioDialog.show();
        }

        else if(view == btn4){
            Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                    showToast(i + "." + (i1 + 1) + "." + i2);
                }
            }, year, month, day);

            datePickerDialog.show();
        }

        else if(view == btn5){
            Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
                @Override
                public void onTimeSet(TimePicker timePicker, int i, int i1) {
                    showToast(i + " : " + i1);
                }
            }, hour, minute, true);

            timePickerDialog.show();
        }

        else if(view == btn6){
            choice = false;
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            // custom dialog 를 위한 layout inflation
            LayoutInflater inflater = (LayoutInflater)getSystemService(LAYOUT_INFLATER_SERVICE);
            View v = inflater.inflate(R.layout.custom_dialog, null);

            builder.setView(v);
            checkBox = v.findViewById(R.id.check);
//            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
//                @Override
//                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
//                    choice = b;
//                }
//            });

            builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    if(checkBox.isChecked()){
                        showToast("USB 접근 허용");
                    }
                    else{
                        showToast("USB 접근 금지");
                    }
                }
            });
            builder.setNegativeButton("취소", null);

            AlertDialog customDialog = builder.create();
            customDialog.show();
        }
    }

    public void showToast(String s){
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
